package com.example.Signupwithgoogleaccount;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SignupwithgoogleaccountApplication {

	public static void main(String[] args) {
		SpringApplication.run(SignupwithgoogleaccountApplication.class, args);
	}

}
