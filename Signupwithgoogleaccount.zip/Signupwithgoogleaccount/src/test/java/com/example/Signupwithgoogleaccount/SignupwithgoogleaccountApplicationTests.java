package com.example.Signupwithgoogleaccount;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SignupwithgoogleaccountApplicationTests {

	@Test
	void contextLoads() {
	}

}
