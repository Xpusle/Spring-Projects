package com.example.SignupAPI;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SignupApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
