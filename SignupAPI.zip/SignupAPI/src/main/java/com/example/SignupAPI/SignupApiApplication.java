package com.example.SignupAPI;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SignupApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(SignupApiApplication.class, args);
	}

}
