package com.Project.LoginAPI;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LoginApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
