package com.example.NewPartice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NewParticeApplicationTests {

	@Test
	void contextLoads() {
	}

}
