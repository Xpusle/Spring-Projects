package com.example.demoVersionOfMyproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoVersionOfMyprojectApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoVersionOfMyprojectApplication.class, args);
	}

}
