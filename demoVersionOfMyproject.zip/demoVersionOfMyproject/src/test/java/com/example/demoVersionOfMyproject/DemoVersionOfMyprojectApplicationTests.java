package com.example.demoVersionOfMyproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoVersionOfMyprojectApplicationTests {

	@Test
	void contextLoads() {
	}

}
